OFFICIAL MOD WEBSITE:
https://northwesttrees-gaming.github.io/mods/nwtg-automation.html

MCREATOR MOD PAGE:
https://mcreator.net/modification/76920/nwtg-automation

BUG REPORTS / FEATURE REQUESTS:
https://github.com/northwesttrees-gaming/NWTG-Automation

OFFICIAL YOUTUBE PLAYLIST
https://www.youtube.com/watch?v=2eLalSnOnHo&list=PL5k7swYOU_yRoly-cK7T7JaSgWH054kxd&ab_channel=NorthWestTreesGaming

/// HOW TO INSTALL MODS: ///

1. Install the Minecraft version.

  - The same game version for the mod/forge must be installed first.
  - If you have the Minecraft version installed already then you can skip this step.

  1.1. Start the Minecraft Launcher
  1.2. Select Java Edition
  1.3. Select Installations
  1.4. Select new installation 
  1.5. Name your installation e.g. Minecraft Vanilla 1.16.5
  1.6. Set the version to match the same version as the mod uses.
  1.7. Set the game directory (See optional steps below.)

  // OPTIONAL STEPS //
  
  - Minecraft likes to through all files into one folder,
    this can cause game incompatibilities when using mods that are
    not supported for that game version.
    It's recommended to select a separate game directory for your 
    installations.

  - You can use something like the below to fix this issue.
    .minecraft/installations/<installation_name_folder>

  1.8. Set the custom game directory for your vanilla Minecraft profile.

2. Download and Install Minecraft Forge

   - You will need the same version of Minecraft to forge as the mod/installation you just made, download and stall the version from the official site below.
     https://files.minecraftforge.net/net/minecraftforge/forge/

   2.1. Download Minecraft forge for the same version.
   2.2. Run the installer and install the client version for your launcher.
   
   - If on windows you will need java installed to run the .jar file.

3. NEW MOD PROFILE
   3.1. Once done run the Minecraft Launcher.
   3.2. Make a new installation for your mod profile. Follow the steps in section 1.
   3.2.1 Instead of installing a vanilla jar search for your new Minecraft Forge installation
   3.3. It is important to keep your mod jars separate so it's best to make a custom directory for your forge installation.
   3.4. Run the game once then close out and move to the next step.

4. ADD YOUR MODS
   4.1. A new folder called mods will be in your root directory for your installation.
   4.2. Navigate to your mods folder.
     4.2.1. Search %appdata% in your windows search bar.
     4.2.2. Open .minecraft then navigate to your installation folder.
   4.3. Drag and drop your mod .jars into this mods folder.

5. RUN THE INSTALLATION
   Test to make sure the game does not have any problems with the mods.
   If the game does not reach the game menu screen and crashes then could mean you have one or more issues with the mods you have installed.

   1. A mod could require additional dependencies API, another mod, etc.
      Read the download site to ensure you have all the dependencies for the mods you
      have installed.
   
   2. A mod may have a conflict with another mod, the easiest way to test if this is the
      the issue is to remove one mod at a time until you can launch the game.
      If you have mods left over then it could be that the last mod you removed
      has issues with one of the mods left in the mods folder.
      
      Try running the mod without any other mods installed to see if its a conflict issue
      if the mod runs properly then it's a conflict issue, try to find out what mod it
      has the issue with by running one of the remaining mods with the issue mod at a
      time, when you find an issue with the other mod, you may contact the developer
      of the mod with the issue to let them know about it.

   3. A mod could also have a version miss match, one of the mods you have installed may be for another forge/Minecraft version. Check the mod download
      pages for the mod to make sure you're not missing any dependencies and have the
      the right version for the Minecraft/forge version you have installed. 