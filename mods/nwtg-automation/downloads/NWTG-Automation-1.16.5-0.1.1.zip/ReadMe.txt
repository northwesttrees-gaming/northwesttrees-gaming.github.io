For bug reports, feature requests, visit our mod's official GitHub project page.
https://github.com/northwesttrees-gaming/NWTG-Automation

For general information and downloads visit our mod website below.
https://northwesttrees-gaming.github.io/mods/nwtg-automation.html